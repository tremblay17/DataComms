// Maxwell Young

#include<iostream>
#include <sys/types.h>   // defines types (like size_t)
#include <sys/socket.h>  // defines socket class
#include <netinet/in.h>  // defines port numbers for (internet) sockets, some address structures, and constants
#include <time.h>        // used for random number generation
#include <string.h> // using this to convert random port integer to string
#include <arpa/inet.h>
#include <stdio.h>
#include <unistd.h>

#define SIZE 1024

using namespace std;

int main(int argc, char *argv[]){
  if(argc != 1){
    cout << "The server must be used with 1 Argument: " << endl;
    cout << "n_port" << endl;
    return 0;
  }
  
  struct sockaddr_in server;
  struct sockaddr_in client;
  int mysocket = 0;
  int i = 0;
  socklen_t clen = sizeof(client);
  char payload[512];
  
  if ((mysocket=socket(AF_INET, SOCK_DGRAM, 0))==-1)
    cout << "Error in socket creation.\n";
  
  memset((char *) &server, 0, sizeof(server));
  server.sin_family = AF_INET;
  server.sin_port = htons(7123);
  server.sin_addr.s_addr = htonl(INADDR_ANY);
  if (bind(mysocket, (struct sockaddr *)&server, sizeof(server)) == -1)
    cout << "Error in binding.\n";
  
  for (i=0; i<5; i++) {
    cout << "I'm waiting for a packet now.\n";
    if (recvfrom(mysocket, payload, 512, 0, (struct sockaddr *)&client, &clen)==-1)
      cout << "Failed to receive.\n";
    cout << "Received data: " << payload << endl;
  }
  
  char ack[]="From Server: Got all that data, thanks!";
  if (sendto(mysocket, ack, 64, 0, (struct sockaddr *)&client, clen)==-1){
    cout << "Error in send to function.\n";
  }
     
  close(mysocket);
  return 0;
}

void handShake(){
  cout << "fuck";
}

void writeFile(int sockfd, struct sockaddr_in addr)
{

  char* filename = "server.txt";
  int n;
  char buffer[SIZE];
  socklen_t addr_size;

  // Creating a file.
  FILE* fp = fp = fopen(filename, "w");

  // Receiving the data and writing it into the file.
  while (1)
  {
    addr_size = sizeof(addr);
    n = recvfrom(sockfd, buffer, SIZE, 0, (struct sockaddr*)&addr, &addr_size);

    if (strcmp(buffer, "END") == 0)
    {
      break;
    }

    printf("[RECEVING] Data: %s", buffer);
    fprintf(fp, "%s", buffer);
    bzero(buffer, SIZE);
  }

  fclose(fp);
}