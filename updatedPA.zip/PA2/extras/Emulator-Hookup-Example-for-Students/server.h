#pragma once

#include <fstream>
#include <string>
#include <sstream>
#include <sys/socket.h>
#include <time.h>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include "packet.h"

class Server
{
	// Common value for network methods to refer to
	constexpr static auto maxDataBuffSize = 30;
	// Give a useful name to packet type magic numbers
	typedef enum
	{
		ACK,
		DATA,
		EOT_SERVER,
		EOT_CLIENT
	} PacketType;
	// Basically syntax sugar for creating Client datat and ACK packets
	class DataPacket : public packet
	{
	public:
		DataPacket() : packet(0, 0, 0, nullptr) {}
	};

	class ACKPacket : public packet
	{
	public:
		ACKPacket(int seqnum, bool eot = false)
			: packet(eot ? EOT_SERVER : ACK, seqnum, 0, nullptr) {}
	};

public:
	/**
	 * Throws an exception on error
	 */
	Server(std::string dataFileName, const std::string& emulatorHostName, const std::string& emulatorPort,
		   const std::string& serverHostName, const std::string& serverPort, std::string logFileName = "arrival.log");
	~Server();

	void start();

private:
	std::string dataFileName;
	std::string logFileName;
	std::ofstream logFile;
	std::stringstream fileData;
	struct sockaddr_storage clientAddr;
	struct addrinfo* serverInfo;
	int sockFd;

	/*
	 * Open and bind to a socket with the new file descriptor being
	 * stored in sockFd
	 */
	void openSocket();
	/*
	 * Blocks until a packet from the client is received.
	 *
	 * Returns a DataPacket that is already deserialized
	 */
	DataPacket receivePacket();
	/*
	 * Sends the packet ack to the client
	 */
	void sendACK(const ACKPacket& ack);
	/*
	 * Writes the data in the packet to fileData
	 */
	void readDataPacket(const DataPacket& p);
	/*
	 * Writes the sequence number in correct format to log file with
	 * the name stored in logFileName
	 */
	void logDataPacket(const DataPacket& p);
	/*
	 * Initializes the addrInfo struct with information provided as
	 * arguments
	 */
	void packAddrInfo(struct addrinfo** addrInfo, const struct addrinfo* addrHints, const std::string& hostName, const std::string& port);
	/*
	 * Writes the contents of fileData to a file with the name stored
	 * in dataFileName
	 */
	void writeToDataFile();
};
