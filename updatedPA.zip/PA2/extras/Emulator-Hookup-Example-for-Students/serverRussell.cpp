#include <array>
#include <cstddef>
#include <cstdlib>
#include <cstring>
#include <exception>
#include <fstream>
#include <ios>
#include <iostream>
#include <netdb.h>
#include <stdexcept>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <vector>
#include "packet.h"
#include "server.h"

Server::Server(std::string dataFileName, [[maybe_unused]] const std::string& emulatorHostName,
			   [[maybe_unused]] const std::string& emulatorPort,const std::string& serverHostName,
			   const std::string& serverPort, std::string logFileName)
	: dataFileName(dataFileName), logFileName(logFileName), serverInfo(nullptr), sockFd(-1)
{
	struct addrinfo hints;

	memset(&hints, 0, sizeof hints);
	hints.ai_family = AF_UNSPEC;
	hints.ai_socktype = SOCK_DGRAM;

	packAddrInfo(&serverInfo, &hints, serverHostName, serverPort);
}

Server::~Server()
{
	freeaddrinfo(serverInfo);
}

// If the seqnum is 1 assign it 0. If the seqnum is 0 assign it 1.
#define FLIP_SEQNUM(seqnum) ((seqnum) = (seqnum) == 1 ? 0 : 1)

void Server::start()
{
	logFile.open(logFileName, std::ios::out | std::ios::trunc);
	if (!logFile.is_open())
		throw std::runtime_error("Could not open log file.");

	openSocket();

	// First seqnum received should be 0
	int prevSeqNum = 1;

	for (;;)
	{
		auto p = receivePacket();

		logDataPacket(p);

		if (p.getSeqNum() == prevSeqNum)
		{
			sendACK(ACKPacket(prevSeqNum));
			continue;
		}

		FLIP_SEQNUM(prevSeqNum);
		if (p.getType() == EOT_CLIENT)
		{
			sendACK(ACKPacket(prevSeqNum, true));
			break;
		}

		sendACK(ACKPacket(prevSeqNum));

		readDataPacket(p);
	}

	writeToDataFile();

	close(sockFd);
	logFile.close();
}

void Server::writeToDataFile()
{
	std::ofstream dataFile(dataFileName, std::ios::out | std::ios::trunc);

	if (!dataFile.is_open())
		throw std::runtime_error("Could not open data file.");

	dataFile << fileData.str();
}

void Server::readDataPacket(const DataPacket& p)
{
	auto pack = const_cast<DataPacket&>(p);
	fileData.write(pack.getData(), pack.getLength());
}

Server::DataPacket Server::receivePacket()
{
	int bytesReceived;
	DataPacket p;
	std::array<char, maxDataBuffSize> buff;
	socklen_t addr_len = sizeof clientAddr;

	if (-1 == (bytesReceived = recvfrom(sockFd, buff.data(), buff.size(), 0, (struct sockaddr*)& clientAddr, &addr_len)))
		throw std::runtime_error("Could not receive packet.");

	p.deserialize(buff.data());

	return p;
}

void Server::sendACK(const ACKPacket& ack)
{
	// The serialize method requires that the buffer be initialized to
	// all zeroes.
	std::array<char, maxDataBuffSize> buff = {0};
	socklen_t addr_len = sizeof clientAddr;

	// The serialize method is incorrectly not labeled as const, so
	// this cast is necessary here to call it.
	const_cast<ACKPacket&>(ack).serialize(buff.data());

	if (-1 == sendto(sockFd, buff.data(), buff.size(), 0, (struct sockaddr*)& clientAddr, addr_len))
		throw std::runtime_error("Could not send ACK.");
}

void Server::packAddrInfo(struct addrinfo** addrInfo, const struct addrinfo* addrHints, const std::string& hostName, const std::string& port)
{
	int errorCode;

	if (0 != (errorCode = getaddrinfo(hostName.c_str(), port.c_str(), addrHints, addrInfo)))
		throw std::runtime_error(gai_strerror(errorCode));
}

void Server::openSocket()
{
	int bindErrorCode;
	auto p = serverInfo;

	for (; p != NULL; p = p->ai_next)
	{
		if (-1 == (sockFd = socket(p->ai_family, p->ai_socktype, p->ai_protocol)))
			continue;


		if (-1 == (bindErrorCode = bind(sockFd, p->ai_addr, p->ai_addrlen)))
		{
			close(sockFd);
			continue;
		}

		break;
	}

	if (NULL == p)
		throw std::runtime_error(strerror(bindErrorCode));
}

void Server::logDataPacket(const DataPacket& p)
{
	// Have to remove the const of p because getSeqNum is incorrectly
	// not labeled as a const method.
	logFile << const_cast<DataPacket&>(p).getSeqNum() << std::endl;
}

int main(int argc, char* argv[])
{
	constexpr auto usageMsg = "Usage: server [emulatorName] [serverPort] [emulatorPort] [dataFileName]";

	if (5 != argc)
	{
		std::cout << usageMsg << std::endl;
		return EXIT_FAILURE;
	}

	++argv; // skip over program name
	std::string emulatorName(argv[0]),
		serverPort(argv[1]),
		emulatorPort(argv[2]),
		dataFileName(argv[3]),
		serverName("localhost");

	try
	{
		Server s(dataFileName, emulatorName, emulatorPort, serverName, serverPort);
		s.start();
	}
	catch(std::exception& e)
	{
		std::cerr << "Error: " << e.what() << std::endl;
		return EXIT_FAILURE;
	}

	return EXIT_SUCCESS;
}
