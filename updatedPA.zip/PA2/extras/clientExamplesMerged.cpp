
// #include <iostream>
// #include <fstream>
// #include <sys/types.h>
// #include <sys/socket.h>
// #include <netinet/in.h>
// #include <netdb.h>
// #include <arpa/inet.h>
// #include <unistd.h>
// #include <cstring>
// #include "packet.h"

// using namespace std;

// #define payLen 30
// #define packetLen 50

// class client {
// private:
//     ofstream *ofileSeq;
//     ofstream *ofileAck;
//     ifstream *myIStream;

// public:
//     client(char *filename, char *seqlog, char *acklog) {
//         ofileSeq = new ofstream(seqlog);
//         ofileAck = new ofstream(acklog);
//         myIStream = new ifstream(filename);
//     }

//     int sendData(int seqNumber, int socket, sockaddr_in &saddr) {
//         char spacket[packetLen];
//         char payload[payLen + 1] = "123456789";

//         packet mySendPacket(1, seqNumber, strlen(payload), payload);
//         mySendPacket.printContents();

//         memset(spacket, 0, packetLen);
//         mySendPacket.serialize(spacket);

//         if (sendto(socket, spacket, sizeof(spacket), 0, (struct sockaddr *) &saddr, sizeof(saddr)) < 0) {
//             cout << "Failed to send payload.\n";
//             return 0;
//         }
//         return 1;
//     }
// };

// int main(int argc, char *argv[]) {
//     struct hostent *em_host;
//     em_host = gethostbyname(argv[1]);
//     if (em_host == NULL) {
//         cout << "Failed to obtain server.\n";
//         exit(EXIT_FAILURE);
//     }

//     // Setup client socket for sending
//     int CESocket = socket(AF_INET, SOCK_DGRAM, 0);
//     if (CESocket < 0) {
//         cout << "Error: failed to open datagram socket.\n";
//     }

//     struct sockaddr_in CE;
//     socklen_t CE_length = sizeof(CE);
//     bzero(&CE, sizeof(CE));
//     CE.sin_family = AF_INET;
//     bcopy((char *) em_host->h_addr, (char *) &CE.sin_addr.s_addr, em_host->h_length);
//     char *end;
//     int em_rec_port = strtol(argv[2], &end, 10);
//     CE.sin_port = htons(em_rec_port);

//     // Setup client socket for receiving
//     int ECSocket = socket(AF_INET, SOCK_DGRAM, 0);
//     if (ECSocket < 0) {
//         cout << "Error: failed to open datagram socket.\n";
//     }

//     struct sockaddr_in EC;
//     socklen_t EC_length = sizeof(EC);
//     bzero(&EC, sizeof(EC));
//     EC.sin_family = AF_INET;
//     EC.sin_addr.s_addr = htonl(INADDR_ANY);
//     char *end2;
//     int cl_rec_port = strtol(argv[3], &end2, 10);
//     EC.sin_port = htons(cl_rec_port);

//     if (bind(ECSocket, (struct sockaddr *) &EC, EC_length) == -1) {
//         cout << "Error in binding.\n";
//     }

//     char slog[] = "seqnum.log";
//     char alog[] = "ack.log";
//     client myClient(argv[4], slog, alog);
//     for (int i = 0; i < 3; i++) {
//         myClient.sendData(0, CESocket, CE);
//     }

//     char serialized[512];
//     memset(serialized, 0, 512);
//     recvfrom(ECSocket, serialized, 512, 0, (struct sockaddr *) &EC, &EC_length);
//     cout << "Received packet and deserialized to obtain the following: " << endl << endl;

//     char ackload[512];
//     memset(ackload, 0, 512);
//     packet rcvdPacket(0, 0, 0, ackload);
//     rcvdPacket.deserialize(serialized);
//     rcvdPacket.printContents();

//     close(CESocket);
//     return 0;
// }
