#include <iostream>
#include <fstream>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <cstring>
#include "packet.h"
#include <sys/time.h>
#include <array>

using namespace std;

class Client {
    constexpr static auto maxDataBuffSize = 30;

    typedef enum {
        ACK,
        DATA,
        EOT_SERVER,
        EOT_CLIENT
    } PacketType;

    class DataPacket : public packet {
    public:
        DataPacket(int seqNum, const string& data)
            : packet(DATA, seqNum, data.length(), const_cast<char*>(data.c_str())) {}
    };

    class ACKPacket : public packet {
    public:
        ACKPacket(int seqnum)
            : packet(ACK, seqnum, 0, nullptr) {}
    };

private:
    std::string inputFileName;
    std::string logSeqNumFileName;
    std::string logAckFileName;
    std::ofstream logFileA;
    std::ofstream logFileSN;
    std::ifstream inputFileData;
    char payload[30];
    struct sockaddr_storage serverAddr;
    struct addrinfo* clientInfo;
    int sockFd;
    int currentSeqNum;
    bool awaitingAck;

public:
    Client(std::string inputFileName, const std::string& emulatorHostName, const std::string& emulatorPort,
           const std::string& clientHostName, const std::string& clientPort, std::string logAckFileName = "ack.log", std::string logSeqNumFileName = "seqnum.log")
        : inputFileName(inputFileName), logAckFileName(logAckFileName), logSeqNumFileName(logSeqNumFileName), clientInfo(nullptr), sockFd(-1), currentSeqNum(0), awaitingAck(false) {
        struct addrinfo hints;
        memset(&hints, 0, sizeof hints);
        hints.ai_family = AF_UNSPEC;
        hints.ai_socktype = SOCK_DGRAM;
        packAddrInfo(&clientInfo, &hints, clientHostName, clientPort);
    }

    ~Client() {
        freeaddrinfo(clientInfo);
    }

    void startClient() {
        logFileA.open(logAckFileName, std::ios::out | std::ios::trunc);
        if (!logFileA.is_open())
            throw std::runtime_error("Could not open log file.");
        logFileSN.open(logSeqNumFileName, std::ios::out | std::ios::trunc);
        if (!logFileSN.is_open())
            throw std::runtime_error("Could not open log file.");

        openSocket();

        while (true) {
            if (!awaitingAck) {
                inputFileData.open(inputFileName, std::ios::in);
                if (!inputFileData.is_open())
                    throw std::runtime_error("Couldn't open input file");

                inputFileData.read(payload, maxDataBuffSize);
                DataPacket p(currentSeqNum, payload);

                sendPacket(p);
                awaitingAck = true;

                try {
                    packet receivedPacket = receivePacket();
                    if (receivedPacket.getType() == ACK) {
                        ackLog << receivedPacket.getSeqNum() << std::endl;
                        if (receivedPacket.getSeqNum() == currentSeqNum) {
                            currentSeqNum = 1 - currentSeqNum; // Toggle sequence number
                            awaitingAck = false;
                        }
                    }
                } catch (const std::runtime_error& e) {
                    // Handle a timeout (no ACK received)
                    resendPacket();
                }
            }
        }

        close(sockFd);
    }

private:
    void openSocket() {
        int bindErrorCode;
        auto p = clientInfo;

        for (; p != NULL; p = p->ai_next) {
            if (-1 == (sockFd = socket(p->ai_family, p->ai_socktype, p->ai_protocol)))
                continue;

            if (-1 == (bindErrorCode = bind(sockFd, p->ai_addr, p->ai_addrlen))) {
                close(sockFd);
                continue;
            }

            serverAddr = *reinterpret_cast<struct sockaddr_storage*>(p->ai_addr);
            break;
        }

        if (NULL == p)
            throw std::runtime_error(strerror(bindErrorCode));
    }

    void packAddrInfo(struct addrinfo** addrInfo, const struct addrinfo* addrHints, const std::string& hostName, const std::string& port) {
        int errorCode;
        if (0 != (errorCode = getaddrinfo(hostName.c_str(), port.c_str(), addrHints, addrInfo)))
            throw std::runtime_error(gai_strerror(errorCode));
    }

    void sendPacket(packet& p) {
        std::array<char, maxDataBuffSize> buffer = {0};
        p.serialize(buffer.data());
        if (-1 == sendto(sockFd, buffer.data(), buffer.size(), 0, (struct sockaddr*)&serverAddr, sizeof(serverAddr)))
            throw std::runtime_error("Could not send packet.");
        seqNumLog << p.getSeqNum() << std::endl;
    }

    packet receivePacket() {
        std::array<char, maxDataBuffSize> buffer = {0};
        socklen_t addr_len = sizeof serverAddr;
        if (recvfrom(sockFd, buffer.data(), buffer.size(), 0, (struct sockaddr*)&serverAddr, &addr_len) == -1)
            throw std::runtime_error("Could not receive packet.");
        packet receivedPacket;
        receivedPacket.deserialize(buffer.data());
        return receivedPacket;
    }

    void resendPacket() {
        // Implement retransmission logic here
    }
};

int main(int argc, char* argv[]) {
    if (argc != 5) {
        std::cout << "Usage: client [emulatorName] [clientPort] [emulatorPort] [dataFileName]" << std::endl;
        return EXIT_FAILURE;
    }

    ++argv; // Skip over program name
    std::string emulatorName(argv[0]), clientPort(argv[1]), emulatorPort(argv[2]), inputFileName(argv[3]), clientHostName("localhost");

    try {
        Client c(inputFileName, emulatorName, emulatorPort, clientHostName, clientPort);
        c.startClient();
    } catch (std::exception& e) {
        std::cerr << "Error: " << e.what() << std::endl;
        return EXIT_FAILURE;
    }

    return EXIT_SUCCESS;
}
