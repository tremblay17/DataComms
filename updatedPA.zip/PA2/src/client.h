
#include <iostream>
#include <fstream>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <cstring>
#include "packet.h"
#include <sys/time.h>

using namespace std;

class Client {
    // Common value for network methods to refer to
	constexpr static auto maxDataBuffSize = 30;
	// Give a useful name to packet type magic numbers
	typedef enum 
	{
		ACK,
		DATA,
		EOT_SERVER,
		EOT_CLIENT
	} PacketType;
	// Basically syntax sugar for creating Client datat and ACK packets
	class DataPacket : public packet
	{
	public:
        DataPacket()
            : packet(0,0,0,nullptr){}
		DataPacket(int seqNum, bool eot = false, char *packetData) 
        : packet(eot ? EOT_CLIENT : DATA, seqNum, maxDataBuffSize, packetData) {}
	};

	class ACKPacket : public packet
	{
	public:
        ACKPacket()
            : packet(0,0,0,nullptr){}
		ACKPacket(int seqnum, bool eot = false)
			: packet(eot ? EOT_SERVER : ACK, seqnum, 0, nullptr) {}
	};
private:
    Client(std::string inputFileName, const std::string& emulatorHostName, const std::string& emulatorPort,
		   const std::string& serverHostName, const std::string& serverPort, std::string logAckFileName = "ack.log", std::string logSeqNumFileName = "seqnum.log");
    ~Client();

    void startClient();
private:
    std::string inputFileName;
    std::string logSeqNumFileName;
	std::string logAckFileName;
	std::ofstream logFileA;
	std::ofstream logFileSN;
    std::ifstream inputFileData;
    char payload[30];
	struct sockaddr_storage serverAddr;
	struct addrinfo* clientInfo;
	int sockFd;

    /*TODO: openSocket();
        readFromFile();
        sendData(); //logSeqNum as they are sent
        receiveAck(); //Should wait before sending next log ack as received
        sendEOT(); 
        */
	
    //Opens and binds the client socket
	void openSocket();
	
    //std::istream readFromFile();

    //Starts a timer and waits for Ack
	packet receiveAck();
	
    //Sends data to server
	void sendPkt(char *data, const DataPacket& p);

    void sendEOT(const DataPacket& p);

    //initializes addrInfo struct using arguments 	
    void packAddrInfo(struct addrinfo** addrInfo, const struct addrinfo* addrHints, const std::string& hostName, const std::string& port);

    //Writes each ack to log file
	void logAck(const packet& ack);
	
    //Writes each seqnum to log file
	void logSeqNum(const packet& p);

    void start();

    /*
    int sendData(int seqNumber, int socket, sockaddr_in &saddr);
    bool readPayload(char* payload);
    int sendPacket(int socket, const char* spacket, sockaddr_in &saddr, int seqNumber, int &retryCount);
    int receiveAck(int socket, sockaddr_in &saddr, int &ackNumber);
    int setupSendingSocket(const char* hostname, const char* port);
    int setupReceivingSocket(const char* port);
    void sendEOTPacket(int socket, sockaddr_in &saddr);
    void closeSockets(int sendSocket, int receiveSocket);
    */
};