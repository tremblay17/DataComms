import random
import time

def binary_exponential_backoff(max_attempts):
    # The maximum number of retries before giving up
    max_retries = min(10, max_attempts)

    # The initial waiting time
    current_backoff = 0

    # The maximum backoff time (in seconds)
    max_backoff = 2 ** max_retries

    # The number of retries so far
    retries = 0

    while retries < max_retries:
        # Calculate the backoff time as a random value between 0 and 2^retries - 1
        current_backoff = random.randint(0, 2 ** retries - 1)

        # Increment the number of retries
        retries += 1

        # Sleep for the calculated backoff time
        sleep_time = min(current_backoff, max_backoff)
        print(f"Attempt {retries}: Sleeping for {sleep_time} seconds...")
        time.sleep(sleep_time)

    print("Max retries reached. Giving up.")

# Example usage with a maximum of 5 attempts
binary_exponential_backoff(5)
