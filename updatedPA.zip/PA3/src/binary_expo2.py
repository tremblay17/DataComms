import random
import time

def binary_exponential_backoff(max_retries=5, base_delay=1, max_delay=16):
    retries = 0

    while retries <= max_retries:
        delay = min(2 ** retries * base_delay, max_delay)
        jitter = random.uniform(0, delay / 2)  # Add jitter to avoid synchronization
        total_delay = delay + jitter

        print(f"Attempt {retries + 1}: Waiting for {total_delay:.2f} seconds")
        time.sleep(total_delay)

        # Simulate success with a probability of 80%
        if random.random() < 0.8:
            print("Success!")
            break
        else:
            print("Transmission failed, retrying...")
            retries += 1

    else:
        print("Max retries reached. Operation failed.")

# Example usage
binary_exponential_backoff()

