#include <iostream>
#include <cstdlib>
#include <ctime>
#include <cmath>
#include <thread>
#include <chrono>

void binaryExponentialBackoff(int max_retries, int base_delay, int max_delay) {
    for (int attempt = 1; attempt <= max_retries; ++attempt) {
        int delay = std::min(static_cast<int>(std::pow(2, attempt) * base_delay), max_delay);
        std::cout << "Attempt " << attempt << ": Waiting for " << delay << " seconds" << std::endl;

        // Simulate success with a probability of 80%
        if (rand() % 100 < 80) {
            std::cout << "Success!" << std::endl;
            break;
        } else {
            std::cout << "Transmission failed, retrying..." << std::endl;
            std::this_thread::sleep_for(std::chrono::seconds(delay));
        }
    }

    std::cout << "Max retries reached. Operation failed." << std::endl;
}

int main() {
    srand(static_cast<unsigned>(time(nullptr)));  // Seed the random number generator

    binaryExponentialBackoff(5, 1, 16);

    return 0;
}
