import time

def linear_backoff(max_retries, base_delay):
    retries = 0

    while retries < max_retries:
        try:
            # Your code that might raise an exception goes here
            result = some_function()
            return result  # Return the result if successful
        except Exception as e:
            print(f"Error: {e}")
            print(f"Retrying in {retries * base_delay} seconds...")
            time.sleep(retries * base_delay)
            retries += 1

    raise Exception("Max retries reached, operation unsuccessful")

def some_function():
    # The function you want to execute, which might raise an exception
    # For demonstration purposes, let's simulate an exception here
    raise ValueError("Simulated error")

# Example usage
try:
    result = linear_backoff(max_retries=3, base_delay=2)
    print(f"Operation successful. Result: {result}")
except Exception as e:
    print(f"Operation failed: {e}")
