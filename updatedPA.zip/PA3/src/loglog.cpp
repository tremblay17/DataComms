#include <iostream>
#include <cmath>

int loglog_backoff(int current_window_size) {
    return static_cast<int>((1 + 1 / log2(log2(current_window_size))) * current_window_size);
}

void loglogBackoff(int max_retries) {
    int window_size = 4;

    for (int attempt = 1; attempt <= max_retries; ++attempt) {
        int current_window_size = loglog_backoff(window_size);
        std::cout << "Attempt " << attempt << ": Window size = " << current_window_size << std::endl;

        // Simulate success with a probability of 80%
        if (rand() % 100 < 80) {
            std::cout << "Success!" << std::endl;
            break;
        } else {
            std::cout << "Transmission failed, retrying..." << std::endl;
            window_size = current_window_size;
        }
    }

    std::cout << "Max retries reached. Operation failed." << std::endl;
}

int main() {
    loglogBackoff(5);

    return 0;
}
