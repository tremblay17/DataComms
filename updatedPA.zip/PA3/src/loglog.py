import math
import random

def loglog_backoff(max_retries=5):
    window_size = 4

    for attempt in range(1, max_retries + 1):
        current_window_size = int((1 + 1 / math.log2(math.log2(window_size))) * window_size)
        print(f"Attempt {attempt}: Window size = {current_window_size}")

        # Simulate success with a probability of 80%
        if random.random() < 0.8:
            print("Success!")
            break
        else:
            print("Transmission failed, retrying...")
            window_size = current_window_size

    else:
        print("Max retries reached. Operation failed.")

# Example usage
loglog_backoff()
